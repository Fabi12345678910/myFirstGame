#include "Client.h"
#include "Inputs.h"
#include "GameUpdate.h"
#include "Renderer.h"
#include "Types.h"
#include "plog/Log.h"
#include "StageManager.h"

#include "Networking/EventDefinitions/EventLoginRequest.h"
#include "Networking/EventDefinitions/EventLoginDenied.h"
#include "Networking/EventDefinitions/EventLoginConfirmation.h"
#include "Networking/EventDefinitions/EventSpawnNewPlayer.h"
#include "Networking/EventDefinitions/EventUserInput.h"
#include "Networking/EventDefinitions/EventGamestatePlayerInputHistory.h"
#include "Networking/EventDefinitions/EventSelectMap.h"
#include "Networking/EventDefinitions/EventSelectedMap.h"
#include "Networking/EventDefinitions/EventEndOfRound.h"
#include "Networking/EventDefinitions/EventEndOfGame.h"
#include "Networking/EventDefinitions/EventStartGame.h"
#include "Networking/EventDefinitions/EventGoToLobby.h"
#include "Networking/EventDefinitions/EventServerHealth.h"

#include "Config.h"
#include <SFML/Window/Keyboard.hpp>
#include <cstdint>
#include <stdexcept>


void* clientEventHandler(std::unique_ptr<Event> evPtr, Connection& conn, void* args) {
    struct clientEventHandlerData *handle = (clientEventHandlerData*) args;
    std::lock_guard<std::mutex> queueLockGuard(handle->connectionEventsMutex);
    handle->connectionEventsQueue.push(std::move(evPtr));
    return NULL;

};

void* udpClientEventHandler(std::unique_ptr<Event> evPtr, std::optional<sf::IpAddress> &remoteAddress, unsigned short &remotePort, void *args){
    PLOG_VERBOSE_IF(debugClientNetworking) << "got udp event";
    struct clientEventHandlerData *handle = (clientEventHandlerData*) args;
    std::lock_guard<std::mutex> queueLockGuard(handle->connectionEventsMutex);
    handle->connectionEventsQueue.push(std::move(evPtr));
    return NULL;
}


Client::Client(sf::RenderWindow& win, bool isHost)
        : renderer(win),
            conn(ClientConnection::createClientConnection({127, 0, 0, 1}, 4444)),
            isHost(isHost)
{
    conn.setArgs(&eventData);
    conn.setEventHandler(clientEventHandler);
    performLogin();
}

// constructor with specified port
Client::Client(sf::RenderWindow& win, sf::IpAddress ip, unsigned short port, bool isHost)
        : renderer(win),
            conn(ClientConnection::createClientConnection(ip, port)),
            isHost(isHost)
{
    sf::View worldView;
    worldView.setSize(sf::Vector2f(1920, 1080));       // virtual world size
    worldView.setCenter(sf::Vector2f(1920.f / 2.f, 1080.f / 2.f));
    win.setView(worldView);

    conn.setArgs(&eventData);
    conn.setEventHandler(clientEventHandler);
    performLogin();
}

void Client::performLogin(){
    conn.sendTcpEvent(EventLoginRequest(conn.getUdpPort()));
    while (true)
    {
        std::lock_guard<std::mutex> queueLockGuard(eventData.connectionEventsMutex);
        while(!eventData.connectionEventsQueue.empty()){
            auto& evPtr = eventData.connectionEventsQueue.front();
            Event* ev = evPtr.get();
            EventLoginConfirmation* evLoginSuccess = dynamic_cast<EventLoginConfirmation*>(ev);
            if(evLoginSuccess != NULL){
                this->playerId = evLoginSuccess->playerId;
                this->tickrateMs = evLoginSuccess->serverTickRateMs;
                tickToDisplay = evLoginSuccess->latestServerTick - displayTickDifference;
                if(evLoginSuccess->latestServerTick < displayTickDifference){
                    throw std::runtime_error("unable to initiate entity interpolation");
                }
                Stage stage = StageManager::loadStage(evLoginSuccess->currentMap);
                this->gameStore.loadStage(stage);
                clientState = C_LOBBY;
                conn.setUdpArgs(&eventData);
                conn.setUdpEventHandler(udpClientEventHandler);
                return;
            }
            EventLoginDenied*evLoginDenied  = dynamic_cast<EventLoginDenied*>(ev);
            if(evLoginDenied != NULL){
                throw std::runtime_error("Login denied");
            }

            // Ignore unrelated events during login to avoid blocking on a non-login packet.
            eventData.connectionEventsQueue.pop();
        }
    }
}

void Client::run(){
    gameStore.setTickrate(sf::milliseconds(this->tickrateMs).asSeconds());
    gameStore.setLocalPlayerId(this->playerId);

    mainLoop();
}

void Client::processEventsAwaitingSpawn(){

    std::lock_guard<std::mutex> queueLockGuard(eventData.connectionEventsMutex);
    while(!eventData.connectionEventsQueue.empty()){
        auto& evPtr = eventData.connectionEventsQueue.front();
        Event* ev = evPtr.get();
        //somehow handle tha event
        EventSpawnNewPlayer *evSpawnNewPlayer = dynamic_cast<EventSpawnNewPlayer*>(ev);
        if(evSpawnNewPlayer != NULL){
            // Only start playing once *we* have spawned.
            if(evSpawnNewPlayer->playerId == this->playerId){
                clientState = C_LOBBY;
            }
        }
        eventData.connectionEventsQueue.pop();
    }
}

void Client::processEventsPlaying(){

    std::lock_guard<std::mutex> queueLockGuard(eventData.connectionEventsMutex);
    while(!eventData.connectionEventsQueue.empty()){
        auto& evPtr = eventData.connectionEventsQueue.front();
        Event* ev = evPtr.get();
        EventGamestatePlayerInputHistory *eventGamestatePlayerInputHistory = dynamic_cast<EventGamestatePlayerInputHistory*>(ev);
        if(eventGamestatePlayerInputHistory != NULL){
            PLOG_VERBOSE_IF(debugClientNetworking) << "handling gameStateUpdate";
            updateGameStates(*eventGamestatePlayerInputHistory);
        }

        EventSelectMap* eventSelectMap = dynamic_cast<EventSelectMap*>(ev);
        if(eventSelectMap != nullptr){
            PLOG_DEBUG_IF(debugClientNetworking) << "Received [Event] Select Map";
            mapSelectionState.selectUntil = eventSelectMap->selectMapUntil;
            mapSelectionState.confirmed = false;
            mapSelectionState.selectedIndex = 0;
            selectedSomething();
            this->clientState = C_MAP_SELECTION;
        }

        EventStartGame* eventStartGame = dynamic_cast<EventStartGame*>(ev);
        if (eventStartGame != nullptr) {
            PLOG_INFO_IF(debugClientNetworking) << "Received [Event] Start Game (stageId=" << eventStartGame->stageId << ")";
            Stage selectedStage = StageManager::loadStage(eventStartGame->stageId);
            this->clientState = C_COUNTDOWN;
            this->gameStartTick = eventStartGame->gameStartTick;
            this->gameStore.loadStage(selectedStage);
            this->endOfRoundScoreboard.clear();
            this->endOfRoundScoreboard[this->playerId] = 0;
            if (GameState* latest = this->gameStore.getGameState(tickToDisplay, true, nullptr)) {
                for (auto itPlayer = latest->getPlayersBegin(); itPlayer != latest->getPlayersEnd(); ++itPlayer) {
                    this->endOfRoundScoreboard[itPlayer->first] = 0;
                }
            }
            this->endOfGameWinnerId = std::nullopt;
        }

        EventEndOfRound* eventEndOfRound = dynamic_cast<EventEndOfRound*>(ev);
        if (eventEndOfRound != nullptr) {
            PLOG_INFO_IF(debugClientNetworking) << "Received [Event] End Of Round";
            this->clientState = C_END_OF_ROUND;
            this->endOfRoundScoreboard.clear();
            for (const auto& line : eventEndOfRound->scores) {
                this->endOfRoundScoreboard[line.playerId] = line.score;
            }
        }

        EventEndOfGame* eventEndOfGame = dynamic_cast<EventEndOfGame*>(ev);
        if (eventEndOfGame != nullptr) {
            PLOG_INFO_IF(debugClientNetworking) << "Received [Event] End Of Game (winnerPlayerId=" << eventEndOfGame->winningPlayerId << ")";
            this->clientState = C_END_OF_GAME;
            this->endOfGameWinnerId = eventEndOfGame->winningPlayerId;
        }

        EventGoToLobby* eventGoToLobby = dynamic_cast<EventGoToLobby*>(ev);
        if (eventGoToLobby != nullptr) {
            PLOG_INFO_IF(debugClientNetworking) << "Received [Event] Go to Lobby";
            this->clientState = C_LOBBY;
            mapSelectionState.confirmed = false;
            this->endOfRoundScoreboard.clear();
            this->endOfGameWinnerId = std::nullopt;
        }

        EventServerHealth *eventServerHealth = dynamic_cast<EventServerHealth*>(ev);
        if(eventServerHealth != NULL){
            PLOG_VERBOSE_IF(debugClientNetworking) << "got a server health";
            this->serverQueueHealth = eventServerHealth->inputsInQueue;
            this->serverFrameTimes.push(eventServerHealth->frameTimeMs);
        }

        EventSpawnNewPlayer *evSpawnNewPlayer = dynamic_cast<EventSpawnNewPlayer*>(ev);
        if(evSpawnNewPlayer != NULL){
            //unused as of now, will be synced at gsUpdate
        }
        eventData.connectionEventsQueue.pop();
    }
}

void Client::updateGameStates(EventGamestatePlayerInputHistory& ev){
    TICK_TYPE currentTickInfo = ev.startingGameTick;
    while (ev.hasNextInfo())
    {
        PLOG_VERBOSE_IF(debugClientNetworking) << "storing updateInfos at tick: " << currentTickInfo;
        LabeledUpdateInfo update = ev.getNextInfo();
        for(auto &pInput : update.info.pInput){
            gameStore.addUpdateInfo(currentTickInfo, pInput);
        }
        if(update.type == UpdateInfo1::GAMESTATE_PLAYER_INPUT){
            gameStore.addUpdateInfo(currentTickInfo, update.info.gsUpdate);
        }
        gameStore.finalizeUpdateInfos(currentTickInfo);
        currentTickInfo++;
    }
}

void Client::storeInputs(const TICK_TYPE& startingTick, const TICK_TYPE& currentTick, playerInput input){
    for (TICK_TYPE tick = startingTick; tick <= currentTick; tick++) {
        if(input.readyToPlay){
            if(!isReadyForSelection()){
                input.readyToPlay = false;
            }else{
                selectedSomething();
            }
        }
        gameStore.setLocalInput(tick, input);
        gameStore.finalizeLocalInput(tick);
    }
}

void Client::sendInputs(const TICK_TYPE& startingTick, const TICK_TYPE& currentTick){
    constexpr size_t maxHistoricInputsToSend = 3;
    for (TICK_TYPE tick = startingTick; tick <= currentTick; tick++) {
        EventUserInput inputs(this->playerId);
        for (TICK_TYPE tickInputToInclude = tick - maxHistoricInputsToSend + 1; tickInputToInclude <= currentTick; tickInputToInclude++) {
            if(gameStore.hasLocalInput(tickInputToInclude)){
                inputs.addUserInput(indexedPlayerInput(tickInputToInclude, gameStore.getLocalInput(tickInputToInclude)));
            }
        }
        conn.sendUdpEvent(inputs);
    }
}

void Client::renderStateSpecificInfo(bool readyToPlay, const GameState& gameState){
    if (this->clientState == C_LOBBY) {
//        TODO make some state PLAYING->READY_SELECTION
//        renderer.renderWaitingMessage();
        renderer.renderReadyMessage(readyToPlay);
    }
    else if (this->clientState == C_MAP_SELECTION) {
        renderer.renderMapSelection(mapSelectionState.selectUntil - tickToDisplay, mapSelectionState.selectedIndex, mapSelectionState.confirmed, mapSelectionState.maps);
    }
    else if (this->clientState == C_WAITING_FOR_COUNTDOWN) {
        renderer.renderLoading();
    }
    else if (this->clientState == C_COUNTDOWN) {
        renderer.renderGameStart(gameStartTick - tickToDisplay);
    }
    else if (this->clientState == C_END_OF_ROUND) {
        std::optional<OBJECT_ID_TYPE> winnerPlayerId = std::nullopt;
        {
            bool hasWinner = false;
            unsigned short bestScore = 0;
            OBJECT_ID_TYPE bestPlayerId = 0;
            for (const auto& [playerId, score] : this->endOfRoundScoreboard) {
                if (!hasWinner || score > bestScore || (score == bestScore && playerId < bestPlayerId)) {
                    hasWinner = true;
                    bestScore = score;
                    bestPlayerId = playerId;
                }
            }
            if (hasWinner) {
                winnerPlayerId = bestPlayerId;
            }
        }

        renderer.renderScore(this->endOfRoundScoreboard, winnerPlayerId);
    }
    else if (this->clientState == C_END_OF_GAME) {
        renderer.renderWinner(this->endOfGameWinnerId);
    }
}

void Client::mainLoop(){
    PLOG_INFO << "entering main loop";
    sf::Clock tickClock;
    tickClock.start();
    sf::Time startTime = tickClock.getElapsedTime();
    sf::Time tickRate = sf::milliseconds(tickrateMs);
    sf::Time latestProcessedInputsTick = startTime;
    TICK_TYPE displayedTicks;

    float loadingAngle = 0.f;

    int dotFrame = 0;
    sf::Clock dotClock;

    while(true){
        sf::Time startTickTime = tickClock.getElapsedTime();
        sf::Time currentDeltaTime = startTickTime - latestProcessedInputsTick;

        TICK_TYPE prevDisplayedTick = tickToDisplay;
        tickToDisplay += (TICK_TYPE) (currentDeltaTime / tickRate);

        #define LOG_TIMEPOINT(name) PLOG_DEBUG_IF(debugClientPerformance) << "timepoint: " << name << ", elapsed tickTime: " <<  (tickClock.getElapsedTime() - startTickTime).asMicroseconds() << "us";
        PLOG_VERBOSE_IF(debugClientFrameGen) << "delta time " << currentDeltaTime.asSeconds();
        PLOG_VERBOSE_IF(debugClientFrameGen) << "tickrate time " << tickRate.asSeconds();

        PLOG_DEBUG_IF(debugClientPerformance) << "--- starting frame ---";
        PLOG_DEBUG_IF(debugClientState) << "clientState: " << clientState;
        processEventsPlaying();
        if(clientState == C_LOBBY){
            LOG_TIMEPOINT("processedEvents");
            storeInputs(prevDisplayedTick + 1, tickToDisplay, processInputs());
            sendInputs(prevDisplayedTick + 1, tickToDisplay);
            LOG_TIMEPOINT("processed playerInputs");
        }
        else if(clientState == C_MAP_SELECTION){
            storeInputs(prevDisplayedTick + 1, tickToDisplay, playerInput());
            // Keep sending neutral inputs so the server doesn't keep applying stale movement.
            sendInputs(prevDisplayedTick + 1, tickToDisplay);
            if(tickToDisplay > mapSelectionState.selectUntil){
                EventSelectedMap eventSelectedMap(mapSelectionState.maps[mapSelectionState.selectedIndex].first);
                if (mapSelectionState.confirmed) {
                    conn.sendTcpEvent(eventSelectedMap);
                }
                clientState = C_WAITING_FOR_COUNTDOWN;
            }
        }
        else if(clientState == C_WAITING_FOR_COUNTDOWN){
            storeInputs(prevDisplayedTick + 1, tickToDisplay, playerInput());
            sendInputs(prevDisplayedTick + 1, tickToDisplay);
            if(tickToDisplay >= gameStartTick - 1){
                clientState = C_GAME_RUNNING;
            }
        }
        else if(clientState == C_COUNTDOWN){
            storeInputs(prevDisplayedTick + 1, tickToDisplay, playerInput());
            sendInputs(prevDisplayedTick + 1, tickToDisplay);
            if(tickToDisplay >= gameStartTick - 1){
                clientState = C_GAME_RUNNING;
            }
        }
        else if (clientState == C_END_OF_ROUND) {
            storeInputs(prevDisplayedTick + 1, tickToDisplay, playerInput());
            sendInputs(prevDisplayedTick + 1, tickToDisplay);
        }
        else if (clientState == C_END_OF_GAME) {
            storeInputs(prevDisplayedTick + 1, tickToDisplay, playerInput());
            sendInputs(prevDisplayedTick + 1, tickToDisplay);
        }
        else if (clientState == C_GAME_RUNNING){
            storeInputs(prevDisplayedTick + 1, tickToDisplay, processInputs());
            sendInputs(prevDisplayedTick + 1, tickToDisplay);
        }
        latestProcessedInputsTick += tickRate * (std::int64_t)(tickToDisplay-prevDisplayedTick);

        Player* localPlayer = NULL;
        PLOG_VERBOSE_IF(debugClientFrameGen) << "attempting to generate gameState at tick: " << tickToDisplay;
        GameState* generatedGameState = gameStore.getGameState(tickToDisplay, true, &localPlayer);  
        LOG_TIMEPOINT("generated gamestate");

        if(generatedGameState != NULL){
            //do interpolation
            GameState interpolatedGameState = *generatedGameState;
            //TODO actually perform interpolation here
            if(localPlayer != NULL){
                constexpr bool renderLocalServerPlayer = false;
                if(!renderLocalServerPlayer){
                    interpolatedGameState.removePlayer(this->playerId);
                }
                localPlayer->getShape().setFillColor(sf::Color::Magenta);
                interpolatedGameState.addPlayer(*localPlayer);
            }
            for (auto it = interpolatedGameState.getPlayersBegin(); it != interpolatedGameState.getPlayersEnd(); it++)
            {
                PLOG_VERBOSE_IF(debugClientFrameGen) << "incl. player: " << it->first << '\n';
            }

            bool readyToPlay = false;
            try {
                readyToPlay = generatedGameState->getPlayer(this->playerId).getReadyToPlay();
            } catch (std::runtime_error e) {
            }
            
            LOG_TIMEPOINT("prepared interpolatedGameState");
            renderer.render(interpolatedGameState);
            LOG_TIMEPOINT("rendered interpolatedGameState");
            renderStateSpecificInfo(readyToPlay, interpolatedGameState);
            LOG_TIMEPOINT("rendered statespecific info");
            

            if (CONF_SHOW_CLIENT_HEALTH){
                auto healthReport = gameStore.getHealthReport(tickToDisplay);
                renderer.renderFrameTimeGraph(clientFrameTimes, (HEALTH_FRAME_TIME_TYPE) tickrateMs, 50.F, 450.F);
                renderer.renderGameStateHealth(healthReport);
                LOG_TIMEPOINT("rendered client health");
            }
            if(CONF_SHOW_SERVER_HEALTH){
                renderer.renderServerQueueHealth(serverQueueHealth);
                renderer.renderFrameTimeGraph(serverFrameTimes, (HEALTH_FRAME_TIME_TYPE) tickrateMs, 50.F, 350.F);
                LOG_TIMEPOINT("rendered server health");
            }

            renderer.display();

            sf::Time tickRenderTime = tickClock.getElapsedTime() - startTickTime;
            clientFrameTimes.push((HEALTH_FRAME_TIME_TYPE) tickRenderTime.asMilliseconds());
            if(tickRenderTime > tickRate){
                PLOG_ERROR << "Computing tick took " << tickRenderTime.asMilliseconds() << "ms, which is slower than the server tickrate";
            }
            LOG_TIMEPOINT("finished frame");
        }else{
            PLOG_DEBUG << "can't render tick " << tickToDisplay;
        }
        if (clientState != clientState::C_MAP_SELECTION) { //this is pfusch should be fixed
            renderer.processDisplayEvents();
        }
        #undef LOG_TIMEPOINT
    }
    PLOG_INFO << "exiting main loop";
}

playerInput Client::processInputs(){ // maybe shouldve used window poll event
    playerInput input;
    
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::A)){
        input.moveLeft = true;
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::D)){
        input.moveRight = true;
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Space)) {
        input.jump = true;
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::J)) {
        input.projectile = true;
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::R)) {
        input.readyToPlay = true; //maximal pfusch
    }

    return input;
}