#pragma once
#include "Types.h"
#include "Collidable.h"
#include "Movable.h"
#include "Config.h"
#include "GameObject.h"
#include <SFML/Graphics.hpp>

class Player : public Collidable, public Movable, public GameObject {
private:
    bool  isOnGround = false;
    float gravity    = defaultGravity;
    float speed      = defaultSpeed;
    float health     = defaultHealth;
    unsigned short score = 0;
    bool readyToPlay = false;
    int16_t  projectileCooldown = 0;
    bool  facing     = FACING_LEFT;

    //the ghostPlayer is only available on Clients and displays the predicted playerState
    static constexpr OBJECT_ID_TYPE ghostPlayerId = 9999;
public:
    static const bool FACING_LEFT = false;
    static const bool FACING_RIGHT = true;

    Player(){};

    Player(OBJECT_ID_TYPE id, sf::Vector2f size, sf::Vector2f position)
        : GameObject(id, size, position) {}

    bool  getIsOnGround() const { return isOnGround; }
    void  setIsOnGround(bool v) { isOnGround = v; }

    float getGravity() const { return gravity; }
    void  setGravity(float g) { gravity = g; }

    float getSpeed() const { return speed; }
    void  setSpeed(float s) { speed = s; }

    float getHealth() const { return health; }
    void  setHealth(float h) { health = h; }

    int16_t getProjectileCooldown() const { return projectileCooldown; }
    void setProjectileCooldown(int16_t c) { projectileCooldown = c; }

    bool getIsGhostPlayer(){return id == ghostPlayerId;};

    bool getFacing() const { return facing; }
    void setFacing(bool f) { facing = f; }

    bool getReadyToPlay() const { return readyToPlay; }
    void setReadyToPlay(bool r) { readyToPlay = r; }

    unsigned short getScore() const { return score; }
    void setScore(unsigned short s) { score = s; }
};